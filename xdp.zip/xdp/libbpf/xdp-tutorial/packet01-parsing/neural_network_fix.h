#include <math.h>
#include <stdlib.h>
#include <stdint.h>

#ifndef __NEURAL_NETWORK_FIX_H
#define __NEURAL_NETWORK_FIX_H

#define N_LAYERS 3 //number of layers
#define MAX_LENGTH_BUFFERS 4 //AUX BUFFERS LENGTH
#define FIXED_POINT_BITS 15 //15 bits represent the fractional part

//inputs and outputs of each layer
static const int outputs[N_LAYERS] = {2, 1,1};
static const int inputs[N_LAYERS] = {4, 2, 1};


//activation functions
typedef enum _EmlNetActivationFunction {
    EmlNetActivationIdentity = 0,
    EmlNetActivationRelu,
    EmlNetActivationFunctions,
} EmlNetActivationFunction;

//struct of a layer
typedef struct _EmlNetLayer {
    int32_t n_outputs;
    int32_t n_inputs;
    const int32_t *weights;
    const int32_t *biases;
    EmlNetActivationFunction activation;
} EmlNetLayer;

//struct of the neural network
typedef struct _EmlNet {
    // Layers of the neural network
    int32_t n_layers;
    const EmlNetLayer *layers;
    // Buffers for storing activations
    int32_t *activations1;
    int32_t *activations2;
    int32_t activations_length;
} EmlNet;

static int32_t model_buf1[MAX_LENGTH_BUFFERS];
static int32_t model_buf2[MAX_LENGTH_BUFFERS];


/*The following commented code corresponds with different neural networks on fixed point used for testing*/

/*static const int32_t model_layer0_weights[24] = { 24, 24, 6, 18, 21, 54, 5, -33, 24, -33, 1222, 45, 56, 27, -984, 33, 33, 21, 0, 0, 0, 0, 0, 0 };
static const int32_t model_layer0_biases[6] = { 40, 25, -30, 50, 500, 270 };
static const int32_t model_layer1_weights[24] = { -456, -8345, -4445, 2456, -1367, -142, -33, 9485, 35069, 2, 145, -234, 234, -2334, -4, 88, -123, -22, -44, 2333, -445, -543, -1884, 1 };
static const int32_t model_layer1_biases[4] = { 1343, 1343, 112, -12 };
static const int32_t model_layer2_weights[8] = { -145, -123, -13434, -13434, -122, -1567, 234, 234 };
static const int32_t model_layer2_biases[2] = { 1, 4 };
static const int32_t model_layer3_weights[2] = { -2, -2 };
static const int32_t model_layer3_biases[1] = { 4 };

static const EmlNetLayer model_layers[4] = { 
    { 6, 4, model_layer0_weights, model_layer0_biases, EmlNetActivationRelu }, 
    { 4, 6, model_layer1_weights, model_layer1_biases, EmlNetActivationRelu }, 
    { 2, 4, model_layer2_weights, model_layer2_biases, EmlNetActivationRelu }, 
    { 1, 2, model_layer3_weights, model_layer3_biases, EmlNetActivationIdentity } };
static const EmlNet model = { 4, model_layers, model_buf1, model_buf2, 6 };*/

/*static const int32_t model_layer0_weights[28] = { 967, 1245, 244, 262, -255, 454, -4332, -322, -1223, -1357, -1097, 11788, -232, 4365, 272, 815, 898, 713, -51, 19, -29, 0, 0, 0, 0, 0, 0, 0 };
static const int32_t model_layer0_biases[7] = { 471, 7706, 701, 804, 799, 50, -456};
static const int32_t model_layer1_weights[28] = { -949, 767, 976, 10843, -497, 1034, 819, 977, -1073, 937, 9829, 731, -1014, 836, 1253, 1375, 1926, -1479, -1494, -118, -485, 112, 1199, 9442, 979, -126, -11410, -1553 };
static const int32_t model_layer1_biases[4] = { 469, -780, -984, -1102 };
static const int32_t model_layer2_weights[8] = { 1555, -1818, -11349, 133, -5919, 1557, 602, 1803 };
static const int32_t model_layer2_biases[2] = { -327, -980 };
static const int32_t model_layer3_weights[2] = { 1094, -1617 };
static const int32_t model_layer3_biases[1] = { -467};


static const EmlNetLayer model_layers[4] = { 
    { 7, 4, model_layer0_weights, model_layer0_biases, EmlNetActivationRelu }, 
    { 4, 7, model_layer1_weights, model_layer1_biases, EmlNetActivationRelu }, 
    { 2, 4, model_layer2_weights, model_layer2_biases, EmlNetActivationRelu }, 
    { 1, 2, model_layer3_weights, model_layer3_biases, EmlNetActivationRelu } };
static const EmlNet model = { 4, model_layers, model_buf1, model_buf2, 7 };*/

//1 segundo - 2 capas
/*static const int32_t model_layer0_weights[4] = { 42625, -12121, 10883, -2860};
static const int32_t model_layer0_biases[1] = { 62833};
static const int32_t model_layer1_weights[1] = { -35706 };
static const int32_t model_layer1_biases[1] = { 72396 };

static const EmlNetLayer model_layers[2] = { 
   { 1, 4, model_layer0_weights, model_layer0_biases, EmlNetActivationRelu }, 
   { 1, 1, model_layer1_weights, model_layer1_biases, EmlNetActivationIdentity }, };

//red neuronal
static const EmlNet model = { 2, model_layers, model_buf1, model_buf2, 4 };*/

//1 segundo - 3 capas
static const int32_t model_layer0_weights[8] = { 51203, 3853, -21013, 16998, 7988, -5358, 12, 0 };
static const int32_t model_layer0_biases[2] = { 43371, -10468 };
static const int32_t model_layer1_weights[2] = { 59604, -7957 };
static const int32_t model_layer1_biases[1] = { 9674 };
static const int32_t model_layer2_weights[1] = { -24584 };
static const int32_t model_layer2_biases[1] = { 54859 };

static const EmlNetLayer model_layers[3] = { 
    { 2, 4, model_layer0_weights, model_layer0_biases, EmlNetActivationRelu }, 
    { 1, 2, model_layer1_weights, model_layer1_biases, EmlNetActivationRelu }, 
    { 1, 1, model_layer2_weights, model_layer2_biases, EmlNetActivationIdentity } };
static EmlNet model = { 3, model_layers, model_buf1, model_buf2, 4 };


//1 segundo - 2,2, 1, 1, 1
/*static const int model_layer0_weights[8] = { 11998, -13722, 16329, 7262, -10809, -9170, 6659, 12286 };
static const float model_layer0_biases[2] = { -13020, -5339 };
static const float model_layer1_weights[4] = { 24056, -13937, -5556, 1867 };
static const float model_layer1_biases[2] = { 9603, -11070 };
static const float model_layer2_weights[2] = { -3523, 4749 };
static const float model_layer2_biases[1] = { 18296 };
static const float model_layer3_weights[1] = {12981 };
static const float model_layer3_biases[1] = { -2056};
static const float model_layer4_weights[1] = { 19770 };
static const float model_layer4_biases[1] = { 32814 };
static const float model_layer5_weights[1] = { -32259 };
static const float model_layer5_biases[1] = { -16646 };
static float model_buf1[4];
static float model_buf2[4];
static const EmlNetLayer model_layers[6] = { 
    { 2, 4, model_layer0_weights, model_layer0_biases, EmlNetActivationLogistic }, 
    { 2, 2, model_layer1_weights, model_layer1_biases, EmlNetActivationLogistic }, 
    { 1, 2, model_layer2_weights, model_layer2_biases, EmlNetActivationLogistic }, 
    { 1, 1, model_layer3_weights, model_layer3_biases, EmlNetActivationLogistic }, 
    { 1, 1, model_layer4_weights, model_layer4_biases, EmlNetActivationLogistic }, 
    { 1, 1, model_layer5_weights, model_layer5_biases, EmlNetActivationLogistic } };
static EmlNet model = { 6, model_layers, model_buf1, model_buf2, 4 };

//5 segundos - 2,2, 1, 1, 1
static const float model_layer0_weights[8] = { -205, 7040, -2056, 0, 0, -147, 12627, -815 };
static const float model_layer0_biases[2] = { -22097, 11290 };
static const float model_layer1_weights[4] = { -19066, 13074, 13453, 0 };
static const float model_layer1_biases[2] = { -21899, 35253 };
static const float model_layer2_weights[2] = { -21595, -21253 };
static const float model_layer2_biases[1] = { -904 };
static const float model_layer3_weights[1] = { 0 };
static const float model_layer3_biases[1] = { 1313};
static const float model_layer4_weights[1] = { -1795};
static const float model_layer4_biases[1] = {-28338 };
static const float model_layer5_weights[1] = { -8694 };
static const float model_layer5_biases[1] = { -4852 };
static float model_buf1[4];\nstatic float model_buf2[4];
static const EmlNetLayer model_layers[6] = { 
    { 2, 4, model_layer0_weights, model_layer0_biases, EmlNetActivationRelu }, 
    { 2, 2, model_layer1_weights, model_layer1_biases, EmlNetActivationRelu }, 
    { 1, 2, model_layer2_weights, model_layer2_biases, EmlNetActivationRelu }, 
    { 1, 1, model_layer3_weights, model_layer3_biases, EmlNetActivationRelu }, 
    { 1, 1, model_layer4_weights, model_layer4_biases, EmlNetActivationRelu }, 
    { 1, 1, model_layer5_weights, model_layer5_biases, EmlNetActivationLogistic } };
static EmlNet model = { 6, model_layers, model_buf1, model_buf2, 4 };



//5 segundos - 1 capas
static const int32_t model_layer0_weights[4] = { -1515, 6264, -3538, 2179};
static const int32_t model_layer0_biases[1] = { 1855};
static const int32_t model_layer1_weights[1] = { 18511 };
static const int32_t model_layer1_biases[1] = { -82925 };*/

//5 segundos - 2,1 capas
/*static const int32_t model_layer0_weights[8] = { -2867, -1303, -12320, 17920, 2990, -254, 0, 0 };
static const int32_t model_layer0_biases[2] = { -26625, 2801 };
static const int32_t model_layer1_weights[2] = { 0, 19189 };
static const int32_t model_layer1_biases[1] = { 22749 };
static const int32_t model_layer2_weights[1] = { 909 };
static const int32_t model_layer2_biases[1] = { -25330 };
*/

//10 segundos - 1 capa
/*static const int32_t model_layer0_weights[4] = {45851, -3124, 16016, 13685 };
static const int32_t model_layer0_biases[1] = { 22852 };
static const int32_t model_layer1_weights[1] = { -10772 };
static const int32_t model_layer1_biases[1] = { 47789 };*/

//10 segundos - 2,1 capas
/*
static const int32_t model_layer0_weights[8] = {32476, 3063, 27226, -4904, 18179, 22424, 3580, 982 };
static const int32_t model_layer0_biases[2] = { 11963, 44421 };
static const int32_t model_layer1_weights[2] = { 10, 43938 };
static const int32_t model_layer1_biases[1] = { -29102 };
static const int32_t model_layer2_weights[1] = { -23291 };
static const int32_t model_layer2_biases[1] = { 10971 };
*/

/*10 segundos  - 2,2, 1, 1, 1
static const float model_layer0_weights[8] = { 0, -13432, 13588,10530, -26230,8617,-6379, 0 };
static const float model_layer0_biases[2] = { 12062, 26724 };
static const float model_layer1_weights[4] = { 41514, 20067,9242, -25833};
static const float model_layer1_biases[2] = { -44596,-2051 };
static const float model_layer2_weights[2] = {21166,-38044 };
static const float model_layer2_biases[1] = { 25431 };
static const float model_layer3_weights[1] = { 6319 };
static const float model_layer3_biases[1] = { 26214 };
static const float model_layer4_weights[1] = { 11041 };
static const float model_layer4_biases[1] = { -46005 };
static const float model_layer5_weights[1] = { 13123 };
static const float model_layer5_biases[1] = { -65936 };
static float model_buf1[4];
static float model_buf2[4];
static const EmlNetLayer model_layers[6] = { 
    { 2, 4, model_layer0_weights, model_layer0_biases, EmlNetActivationRelu }, 
    { 2, 2, model_layer1_weights, model_layer1_biases, EmlNetActivationRelu }, 
    { 1, 2, model_layer2_weights, model_layer2_biases, EmlNetActivationRelu }, 
    { 1, 1, model_layer3_weights, model_layer3_biases, EmlNetActivationRelu }, 
    { 1, 1, model_layer4_weights, model_layer4_biases, EmlNetActivationRelu }, 
    { 1, 1, model_layer5_weights, model_layer5_biases, EmlNetActivationLogistic } };
static EmlNet model = { 6, model_layers, model_buf1, model_buf2, 4 };*/


/*ReLU function*/
static __always_inline int32_t relu_fixed(int32_t x_fixed) {
  int32_t relu_x_fixed;
  int32_t x_int = x_fixed >> FIXED_POINT_BITS; // Convertimos a entero
  if (x_int >= 0) {
    relu_x_fixed = x_fixed;
  } else {
    relu_x_fixed = 0;
  }
  return relu_x_fixed;
}

//multiplication in fixed point
static __always_inline int32_t mult (int32_t a, int32_t b){
    int64_t prod = (int64_t)a * (int64_t) b;
    prod >>= FIXED_POINT_BITS;
    return (int32_t)prod;
}

//mathematics of each layer
//input: layer, input buffer, output buffer and number of layer
static __always_inline int32_t eml_net_layer_forward(const EmlNetLayer *layer, int32_t * in, int32_t * out, int32_t n_layer){
    
	int w_idx;
	int32_t w;

    #pragma unroll
    for (int o=0; o < outputs[n_layer]; o++) {
        int32_t sum = 0;
        #pragma unroll
        for (int i=0; i<inputs[n_layer]; i++) {
            w_idx = o+(i*outputs[n_layer]); // index
            w = layer->weights[w_idx]; //weight*input
            sum += mult(w, in[i]); 
        }
    // bias + (weight * input)
        out[o] = sum + layer->biases[o];

    }

    

    //activation funciton
    if (layer->activation == EmlNetActivationIdentity) {
        // no-op
    } else if (layer->activation == EmlNetActivationRelu) {
        #pragma unroll
	    for (int i=0; i<outputs[n_layer]; i++) {
            out[i] =relu_fixed(out[i]);
        }
    } 
    else {
        return -1;
    }

	return 0;
}

//Neural network logic 
static __always_inline int32_t eml_net_infer(const EmlNet * model, int32_t * features){   
    
    //aux buffers
    int32_t * buffer1 = model->activations1;
    int32_t *buffer2 = model->activations2;

	// Input layer
    eml_net_layer_forward(&model->layers[0], features, buffer1, 0);

    // Hidden layers
    #pragma unroll
    for (int l=1; l<N_LAYERS-1; l++) {
        const EmlNetLayer *layer = &model->layers[l];//current layer
        //aplicamos la logica a la capa
        eml_net_layer_forward(layer, buffer1, buffer2, l);
        #pragma unroll
	    for (int i=0; i<MAX_LENGTH_BUFFERS; i++) {
            buffer1[i] = buffer2[i]; 
        }
    }	
	
    // Output layer
    eml_net_layer_forward(&model->layers[N_LAYERS-1], buffer1, buffer2, N_LAYERS-1);;				

    return 0;
}

//this function calls the neural network and makes the final classification
static __always_inline int32_t eml_net_predict(const EmlNet * model, int32_t * features){
    eml_net_infer(model, features); //this calls the neural network

    int32_t out_fix = model->activations2[0];
    int32_t out_int = out_fix >> FIXED_POINT_BITS; // converting Fixed -> integer
    /*Avoiding sigmoid function with this*/
    if (out_int > 0) {
        return 1;
    } else {
     return 0;
    }
}

/*Converting integer -> fixed point integer*/
static __always_inline int32_t to_fix(int32_t entrie){
    int32_t a = entrie << FIXED_POINT_BITS;
    int32_t output = round(a);
    if (a < 0){// this applies the sign
        output = abs(output);
        output = ~output;
        output++;
    }
    return output;
}

static __always_inline int32_t model_predict(int32_t * in)
{
    int32_t fix_entries[4] = {to_fix(in[0]), to_fix(in[1]), to_fix(in[2]), to_fix(in[3])}; 
    return eml_net_predict(&model, fix_entries);
}

#endif