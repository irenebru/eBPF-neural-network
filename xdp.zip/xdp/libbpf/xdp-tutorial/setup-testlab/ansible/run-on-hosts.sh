#!/bin/bash -x
ansible-playbook -i hosts site.yml
